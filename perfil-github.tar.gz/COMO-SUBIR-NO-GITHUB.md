# Como subir no GitHub (passo a passo)

Conta: **beatrizcampos-dev** (github.com/beatrizcampos-dev). Tudo pelo GitHub Desktop, sem terminal.

## 1. Perfil com layout (10 min)

1. GitHub Desktop → File → Add local repository → escolha a pasta `GitHub/beatrizcampos-dev`.
2. Ele vai dizer que não é um repositório: clique em **create a repository**. Nome: `beatrizcampos-dev` (tem que ser igual ao usuário). Create.
3. Commit "Perfil com layout" → **Publish repository** → **desmarque** "Keep this code private" → Publish.
4. Ative a cobrinha (só uma vez):
   - Abra https://github.com/beatrizcampos-dev/beatrizcampos-dev/actions
   - Clique em "Cobrinha das contribuições" → **Run workflow** → Run.
   - Em ~1 minuto a animação aparece no perfil. Depois ela se atualiza sozinha todo dia.
5. Abra https://github.com/beatrizcampos-dev: o README aparece no topo do perfil.

> Os cards de estatísticas, linguagens e troféus começam vazios e vão enchendo conforme ela sobe projetos e faz commits. Isso é normal em conta nova.

## 2. Portfólio (10 min)

1. GitHub Desktop → File → Add local repository → pasta `GitHub/portfolio-beatriz` → create a repository, nome `portfolio`.
2. Commit "Primeira versão do portfólio" → Publish repository (público).
3. Testar no PC: abra a pasta no VS Code → terminal → `npm install` → `npm run dev` → http://localhost:3000.

## 3. Colocar o portfólio no ar (Vercel, 5 min)

1. https://vercel.com/new → entrar com o GitHub → importar `portfolio` → Deploy.
2. Copiar o link (ex.: `portfolio-xxx.vercel.app`) e colocar:
   - no `README.md` do portfólio (onde diz "link da Vercel aqui");
   - no perfil do GitHub em https://github.com/settings/profile → campo **URL**;
   - no LinkedIn (Destaque e Dados de contato → Site).

## 4. Fixar o portfólio

No perfil → "Customize your pins" → marcar `portfolio`.
